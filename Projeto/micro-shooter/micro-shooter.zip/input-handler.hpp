#ifndef INPUT_HANDLER_HPP
#define INPUT_HANDLER_HPP

#include "game.hpp"  // Inclui o cabe�alho da classe Game

// Declara��o da fun��o handleInput
void handleInput(Game* game);

#endif // INPUT_HANDLER_HPP
