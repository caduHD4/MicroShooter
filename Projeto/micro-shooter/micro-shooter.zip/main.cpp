#include "game.hpp"

int main(int argc, char* argv[]) {
	Game game = Game();

	return 0;
}
